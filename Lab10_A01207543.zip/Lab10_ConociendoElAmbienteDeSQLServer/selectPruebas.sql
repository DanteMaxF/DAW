SELECT * FROM Materiales

SELECT * FROM Proyectos

SELECT * FROM Proveedores

SELECT * FROM Entregan